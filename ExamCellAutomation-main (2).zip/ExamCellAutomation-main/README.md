# ExamCellAutomation

## Command 1
pip install virtualenv


1. Download Repo zip file and extract
2. Open the folder in cmd promt


## Command 2
virtualenv test


## Command 3
test\scripts\activate


## command 4
pip install requirements.txt


## command 5
python flask_app.py
